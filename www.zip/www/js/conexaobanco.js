var config = {
  apiKey: "AIzaSyAw1C4tC-OMvd6tjGwdL8UTgEpzu4p7KNo",
  authDomain: "vitorbomba-bikcraft.firebaseapp.com",
  databaseURL: "https://vitorbomba-bikcraft.firebaseio.com",
  projectId: "vitorbomba-bikcraft",
  storageBucket: "vitorbomba-bikcraft.appspot.com",
  messagingSenderId: "591558816412"
};
firebase.initializeApp(config);
